package com.example.metronomeproject;

public class ToyPack extends Pack {
    public ToyPack() {
        super("toyPack/Perc_ClickToy_hi.wav", "toyPack/Perc_ClickToy_lo.wav");
    }
}
