package com.example.metronomeproject;

import javafx.scene.media.AudioClip;

public class RefPack extends Pack{
    public RefPack() {
        super("refPack/Perc_WhistleRef_hi.wav", "refPack/Perc_WhistleRef_lo.wav");
    }
}
