package com.example.metronomeproject;

public class TimeSignature {
    int topSignatureNumber, bottomSignatureNumber;

    public void setTopSignatureNumber(int topSignatureNumber) {
        this.topSignatureNumber = topSignatureNumber;
    }

    public void setBottomSignatureNumber(int bottomSignatureNumber) {
        this.bottomSignatureNumber = bottomSignatureNumber;
    }
}
