package com.example.metronomeproject;

public class TambPack extends Pack{
    public TambPack() {
        super("tambPack/Perc_Tamb_C_hi.wav", "tambPack/Perc_Tamb_C_lo.wav");
    }
}
