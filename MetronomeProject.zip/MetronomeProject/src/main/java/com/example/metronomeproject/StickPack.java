package com.example.metronomeproject;

public class StickPack extends Pack {
    public StickPack() {
        super("stickPack/Perc_Stick_hi.wav", "stickPack/Perc_Stick_lo.wav");
    }
}
