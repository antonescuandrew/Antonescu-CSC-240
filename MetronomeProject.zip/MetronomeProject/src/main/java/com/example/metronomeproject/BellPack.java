package com.example.metronomeproject;

import javafx.scene.media.AudioClip;

public class BellPack extends Pack{
    public BellPack() {
        super("bellPack/Synth_Bell_B_hi.wav", "bellPack/Synth_Bell_B_lo.wav");
    }
}
