package com.example.metronomeproject;

import javafx.scene.media.AudioClip;

import java.util.Timer;

public class QuartzPack extends Pack{

    public QuartzPack() {
        super("quartzPack/Perc_MetronomeQuartz_hi.wav", "quartzPack/Perc_MetronomeQuartz_lo.wav");
    }
}
