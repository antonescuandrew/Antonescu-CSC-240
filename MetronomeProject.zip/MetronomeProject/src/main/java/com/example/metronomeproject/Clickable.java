package com.example.metronomeproject;

public interface Clickable {
    void highClick();
    void lowClick();
    void play();
}
